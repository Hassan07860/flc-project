#!/bin/bash
# build.sh - Compile and run the FLC Booking System

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$PROJECT_DIR/src/main/java"
TEST_SRC="$PROJECT_DIR/src/test/java"
LIB="$PROJECT_DIR/lib"
OUT="$PROJECT_DIR/out"
TEST_OUT="$PROJECT_DIR/out/test"

mkdir -p "$OUT" "$TEST_OUT"

echo "=== Compiling main sources ==="
javac -d "$OUT" -sourcepath "$SRC" $(find "$SRC" -name "*.java")
if [ $? -ne 0 ]; then echo "COMPILE ERROR"; exit 1; fi

echo "=== Compiling test sources ==="
javac -cp "$OUT:$LIB/junit-4.13.2.jar:$LIB/hamcrest-core-1.3.jar" \
      -d "$TEST_OUT" -sourcepath "$TEST_SRC" $(find "$TEST_SRC" -name "*.java")
if [ $? -ne 0 ]; then echo "TEST COMPILE ERROR"; exit 1; fi

echo "=== Running JUnit Tests ==="
java -cp "$OUT:$TEST_OUT:$LIB/junit-4.13.2.jar:$LIB/hamcrest-core-1.3.jar" \
     org.junit.runner.JUnitCore flc.BookingServiceTest

echo ""
echo "=== Creating executable JAR ==="
echo "Main-Class: flc.ui.MainApp" > "$OUT/MANIFEST.MF"
jar cfm "$PROJECT_DIR/FLC-Booking-System.jar" "$OUT/MANIFEST.MF" -C "$OUT" .
echo "✓ JAR created: FLC-Booking-System.jar"
echo ""
echo "=== Running Demo (auto mode) ==="
echo "8" | java -jar "$PROJECT_DIR/FLC-Booking-System.jar"
