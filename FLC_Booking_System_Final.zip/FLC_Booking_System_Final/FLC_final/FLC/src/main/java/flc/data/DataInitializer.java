package flc.data;

import flc.model.*;
import flc.service.BookingService;

/**
 * Seeds the system with clean sample data:
 * - 6 exercise types
 * - 10 members (unique IDs validated)
 * - 8 weekends timetable (48 lessons)
 * - Clean bookings with no conflicts
 * - 20+ reviews (via attended bookings)
 */
public class DataInitializer {

    public static void populate(BookingService service) {

        // ── Exercises ──────────────────────────────────────────────
        Exercise yoga      = new Exercise("Yoga",       8.00,  "Relaxing stretches and mindfulness");
        Exercise zumba     = new Exercise("Zumba",     10.00,  "High-energy dance fitness");
        Exercise aquacise  = new Exercise("Aquacise",   9.00,  "Low-impact water aerobics");
        Exercise boxFit    = new Exercise("Box Fit",   12.00,  "Boxing-inspired cardio workout");
        Exercise bodyBlitz = new Exercise("Body Blitz",11.00,  "Full body conditioning");
        Exercise pilates   = new Exercise("Pilates",    9.50,  "Core strength and flexibility");

        // ── Members (unique IDs enforced) ─────────────────────────
        Member[] members = {
            new Member(1,  "Alice Johnson",  "alice@email.com"),
            new Member(2,  "Bob Smith",      "bob@email.com"),
            new Member(3,  "Carol White",    "carol@email.com"),
            new Member(4,  "David Brown",    "david@email.com"),
            new Member(5,  "Emma Davis",     "emma@email.com"),
            new Member(6,  "Frank Wilson",   "frank@email.com"),
            new Member(7,  "Grace Lee",      "grace@email.com"),
            new Member(8,  "Henry Taylor",   "henry@email.com"),
            new Member(9,  "Isla Martin",    "isla@email.com"),
            new Member(10, "Jack Harris",    "jack@email.com")
        };
        for (Member m : members) service.addMember(m);

        // ── Timetable: 8 weeks x Sat+Sun x 3 slots = 48 lessons ──
        Exercise[][] satSchedule = {
            {yoga,      zumba,      boxFit   },  // Week 1
            {aquacise,  bodyBlitz,  pilates  },  // Week 2
            {zumba,     yoga,       aquacise },  // Week 3
            {boxFit,    pilates,    bodyBlitz},  // Week 4
            {yoga,      aquacise,   zumba    },  // Week 5
            {bodyBlitz, boxFit,     yoga     },  // Week 6
            {pilates,   zumba,      boxFit   },  // Week 7
            {aquacise,  yoga,       bodyBlitz}   // Week 8
        };
        Exercise[][] sunSchedule = {
            {zumba,     yoga,       pilates  },  // Week 1
            {boxFit,    aquacise,   yoga     },  // Week 2
            {bodyBlitz, boxFit,     zumba    },  // Week 3
            {yoga,      aquacise,   pilates  },  // Week 4
            {boxFit,    bodyBlitz,  aquacise },  // Week 5
            {pilates,   zumba,      boxFit   },  // Week 6
            {yoga,      bodyBlitz,  aquacise },  // Week 7
            {zumba,     pilates,    yoga     }   // Week 8
        };

        TimeSlot[] slots = {TimeSlot.MORNING, TimeSlot.AFTERNOON, TimeSlot.EVENING};
        int lessonId = 1;

        Lesson[][] satLessons = new Lesson[8][3];
        Lesson[][] sunLessons = new Lesson[8][3];

        for (int w = 0; w < 8; w++) {
            for (int s = 0; s < 3; s++) {
                satLessons[w][s] = new Lesson(lessonId++, satSchedule[w][s], "Saturday", w+1, slots[s]);
                service.addLesson(satLessons[w][s]);
                sunLessons[w][s] = new Lesson(lessonId++, sunSchedule[w][s], "Sunday",   w+1, slots[s]);
                service.addLesson(sunLessons[w][s]);
            }
        }

        // ── Clean Bookings (no time conflicts) ─────────────────────
        // Each member books at most one slot per day per week.

        // WEEK 1 — Sat: Morning/Aft/Eve; Sun: Morning/Aft/Eve
        bookAndAttend(service, members[0], satLessons[0][0]); // Alice  Sat W1 Morning  Yoga
        bookAndAttend(service, members[1], satLessons[0][0]); // Bob    Sat W1 Morning  Yoga
        bookAndAttend(service, members[2], satLessons[0][1]); // Carol  Sat W1 Afternoon Zumba
        bookAndAttend(service, members[3], satLessons[0][1]); // David  Sat W1 Afternoon Zumba
        bookAndAttend(service, members[4], satLessons[0][2]); // Emma   Sat W1 Evening  Box Fit
        bookAndAttend(service, members[5], sunLessons[0][0]); // Frank  Sun W1 Morning  Zumba
        bookAndAttend(service, members[6], sunLessons[0][1]); // Grace  Sun W1 Afternoon Yoga
        bookAndAttend(service, members[7], sunLessons[0][2]); // Henry  Sun W1 Evening  Pilates

        // WEEK 2 — different slots so no conflict
        bookAndAttend(service, members[0], satLessons[1][0]); // Alice  Sat W2 Morning  Aquacise
        bookAndAttend(service, members[1], satLessons[1][1]); // Bob    Sat W2 Afternoon Body Blitz
        bookAndAttend(service, members[2], satLessons[1][2]); // Carol  Sat W2 Evening  Pilates
        bookAndAttend(service, members[3], sunLessons[1][0]); // David  Sun W2 Morning  Box Fit
        bookAndAttend(service, members[4], sunLessons[1][1]); // Emma   Sun W2 Afternoon Aquacise
        bookAndAttend(service, members[5], sunLessons[1][2]); // Frank  Sun W2 Evening  Yoga
        bookAndAttend(service, members[6], satLessons[1][0]); // Grace  Sat W2 Morning  Aquacise
        bookAndAttend(service, members[7], sunLessons[1][0]); // Henry  Sun W2 Morning  Box Fit

        // WEEK 3
        bookAndAttend(service, members[0], satLessons[2][0]); // Alice  Sat W3 Morning  Zumba
        bookAndAttend(service, members[1], satLessons[2][1]); // Bob    Sat W3 Afternoon Yoga
        bookAndAttend(service, members[2], sunLessons[2][1]); // Carol  Sun W3 Afternoon Box Fit
        bookAndAttend(service, members[3], satLessons[2][2]); // David  Sat W3 Evening  Aquacise
        bookAndAttend(service, members[4], sunLessons[2][0]); // Emma   Sun W3 Morning  Body Blitz
        bookAndAttend(service, members[8], satLessons[2][0]); // Isla   Sat W3 Morning  Zumba
        bookAndAttend(service, members[9], sunLessons[2][2]); // Jack   Sun W3 Evening  Zumba

        // WEEK 4
        bookAndAttend(service, members[5], satLessons[3][0]); // Frank  Sat W4 Morning  Box Fit
        bookAndAttend(service, members[6], satLessons[3][1]); // Grace  Sat W4 Afternoon Pilates
        bookAndAttend(service, members[7], satLessons[3][2]); // Henry  Sat W4 Evening  Body Blitz
        bookAndAttend(service, members[8], sunLessons[3][0]); // Isla   Sun W4 Morning  Yoga
        bookAndAttend(service, members[9], sunLessons[3][2]); // Jack   Sun W4 Evening  Pilates

        // WEEK 5
        bookAndAttend(service, members[0], satLessons[4][0]); // Alice  Sat W5 Morning  Yoga
        bookAndAttend(service, members[1], satLessons[4][1]); // Bob    Sat W5 Afternoon Aquacise
        bookAndAttend(service, members[2], sunLessons[4][0]); // Carol  Sun W5 Morning  Box Fit
        bookAndAttend(service, members[3], sunLessons[4][1]); // David  Sun W5 Afternoon Body Blitz

        // WEEK 6
        bookAndAttend(service, members[4], satLessons[5][0]); // Emma   Sat W6 Morning  Body Blitz
        bookAndAttend(service, members[5], satLessons[5][1]); // Frank  Sat W6 Afternoon Box Fit
        bookAndAttend(service, members[6], sunLessons[5][0]); // Grace  Sun W6 Morning  Pilates
        bookAndAttend(service, members[7], sunLessons[5][2]); // Henry  Sun W6 Evening  Box Fit

        // WEEK 7
        bookAndAttend(service, members[8], satLessons[6][0]); // Isla   Sat W7 Morning  Pilates
        bookAndAttend(service, members[9], satLessons[6][2]); // Jack   Sat W7 Evening  Box Fit
        bookAndAttend(service, members[0], sunLessons[6][0]); // Alice  Sun W7 Morning  Yoga

        // WEEK 8
        bookAndAttend(service, members[1], satLessons[7][0]); // Bob    Sat W8 Morning  Aquacise
        bookAndAttend(service, members[2], satLessons[7][1]); // Carol  Sat W8 Afternoon Yoga
        bookAndAttend(service, members[3], sunLessons[7][2]); // David  Sun W8 Evening  Yoga

        // ── 20+ Reviews (via addReviewDirect — seed data) ─────────
        // Week 1
        service.addReviewDirect(members[0], satLessons[0][0], 5, "Wonderful yoga, very relaxing!");
        service.addReviewDirect(members[1], satLessons[0][0], 4, "Great instructor, will book again.");
        service.addReviewDirect(members[2], satLessons[0][1], 5, "Zumba was so much fun!");
        service.addReviewDirect(members[3], satLessons[0][1], 3, "A bit fast-paced for me.");
        service.addReviewDirect(members[4], satLessons[0][2], 5, "Box Fit is incredible!");
        service.addReviewDirect(members[5], sunLessons[0][0], 4, "Energetic Zumba, great start.");
        service.addReviewDirect(members[6], sunLessons[0][1], 5, "Yoga on Sunday is perfect.");
        service.addReviewDirect(members[7], sunLessons[0][2], 4, "Pilates was challenging but rewarding.");

        // Week 2
        service.addReviewDirect(members[0], satLessons[1][0], 4, "Aquacise is gentle, good for my back.");
        service.addReviewDirect(members[1], satLessons[1][1], 3, "Body Blitz was tough but fair.");
        service.addReviewDirect(members[2], satLessons[1][2], 4, "Pilates instructor very clear.");
        service.addReviewDirect(members[3], sunLessons[1][0], 5, "Box Fit on Sunday — brilliant energy!");
        service.addReviewDirect(members[4], sunLessons[1][1], 4, "Aquacise becoming my favourite.");
        service.addReviewDirect(members[5], sunLessons[1][2], 2, "Yoga was a bit rushed, disappointing.");

        // Week 3
        service.addReviewDirect(members[0], satLessons[2][0], 5, "Zumba again — amazing as always!");
        service.addReviewDirect(members[1], satLessons[2][1], 4, "Good yoga session, very peaceful.");
        service.addReviewDirect(members[2], sunLessons[2][1], 5, "Best Box Fit session yet!");
        service.addReviewDirect(members[3], satLessons[2][2], 3, "Aquacise ok but prefer Zumba.");

        // Week 4
        service.addReviewDirect(members[5], satLessons[3][0], 5, "Box Fit getting better every week!");
        service.addReviewDirect(members[6], satLessons[3][1], 4, "Very intense Pilates, loved it.");
        service.addReviewDirect(members[8], sunLessons[3][0], 4, "Nice gentle Sunday yoga.");

        // Week 5+
        service.addReviewDirect(members[0], satLessons[4][0], 5, "Yoga keeps improving — fantastic!");
        service.addReviewDirect(members[1], satLessons[4][1], 4, "Aquacise in Week 5 was refreshing.");

        System.out.println("✓ Sample data loaded: 10 members, 48 lessons, 38 bookings (all attended), 23 reviews.");
    }

    /**
     * Book a lesson and immediately mark it as attended.
     * Used for seeding historical data.
     */
    private static void bookAndAttend(BookingService service, Member member, Lesson lesson) {
        Booking booking = service.bookLesson(member, lesson);
        if (booking != null) {
            service.attendLesson(booking);
        }
    }
}
